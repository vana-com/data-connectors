/**
 * YouTube Connector (Playwright)
 *
 * Uses Playwright for real browser control to extract YouTube user data.
 * Requires the playwright-runner sidecar.
 *
 * Collects:
 *   - youtube.profile      (email, channel URL, handle, joinedDate, stats)
 *   - youtube.subscriptions
 *   - youtube.playlists
 *   - youtube.playlistItems
 *   - youtube.likes        (Liked Videos playlist: list=LL)
 *   - youtube.watchLater   (Watch Later playlist:  list=WL)
 *   - youtube.history      (top 50 most recent entries, with watchedAtText from date headers)
 */

// ─── State ────────────────────────────────────────────────────
const state = {
  email: null,
  profile: null,
  subscriptions: [],
  playlists: [],
  playlistItems: {},
  likes: [],
  watchLater: [],
  history: [],
  isLoggedIn: false,
  isComplete: false
};

// ─── Constants ────────────────────────────────────────────────
const MAX_SUBS = 20;
const MAX_SCROLLS_PLAYLISTS = 5;
const MAX_SCROLLS_PLAYLIST_ITEMS = 20;
const MAX_SCROLLS_HISTORY = 4;
const MAX_HISTORY_ITEMS = 50;
const MAX_PLAYLISTS = 50;

// ─── Helpers ──────────────────────────────────────────────────

// Parse human-readable count strings (e.g. "5.3M subscribers", "1,234 views") → integer
const parseCount = (text) => {
  if (!text) return null;
  const t = String(text).replace(/,/g, '');
  const m = t.match(/([\d.]+)\s*([KkMmBb]?)/);
  if (!m) return null;
  const num = parseFloat(m[1]);
  const mult = { K: 1e3, M: 1e6, B: 1e9 }[m[2].toUpperCase()] || 1;
  return isNaN(num) ? null : Math.round(num * mult);
};

// ─── Login Detection ─────────────────────────────────────────

const YOUTUBE_ACCOUNT_MENU_SELECTOR = [
  'button#avatar-btn',
  'ytd-topbar-menu-button-renderer button#avatar-btn',
  'button[aria-label="Account menu"]',
  '#avatar-btn yt-img-shadow img',
  'ytd-topbar-menu-button-renderer img'
].join(', ');

const YOUTUBE_SIGN_IN_LINK_SELECTOR =
  'a[href*="ServiceLogin"], a[href*="accounts.google.com/ServiceLogin"]';

const waitForCondition = async (checkFn, { timeout = 5000, interval = 250 } = {}) => {
  const deadline = Date.now() + timeout;

  while (Date.now() < deadline) {
    try {
      const result = await checkFn();
      if (result) {
        return result;
      }
    } catch (err) {
      // Retry until timeout. This is an explicit wait, not a blind fixed delay.
    }

    await page.sleep(interval);
  }

  return null;
};

const getYoutubeSessionState = async () => {
  const currentUrl = await page.url();

  const domState = await page.evaluate(`
    (() => {
      const accountMenu = document.querySelector(${JSON.stringify(YOUTUBE_ACCOUNT_MENU_SELECTOR)});
      const signInLink = document.querySelector(${JSON.stringify(YOUTUBE_SIGN_IN_LINK_SELECTOR)});
      const interstitialButtons = Array.from(
        document.querySelectorAll('button, a, tp-yt-paper-button')
      ).some((btn) => {
        const text = (btn.textContent || '').trim().toLowerCase();
        return (
          text === 'not now' ||
          text === 'skip' ||
          text === 'no thanks' ||
          text === 'continue' ||
          text === 'done'
        );
      });

      return {
        hasAccountMenu: !!accountMenu,
        hasSignInLink: !!signInLink,
        hasInterstitialButtons: interstitialButtons,
      };
    })()
  `);

  return {
    currentUrl,
    isOnYoutube: currentUrl.includes('youtube.com'),
    isOnGoogleAuth:
      currentUrl.includes('accounts.google.com') ||
      currentUrl.includes('myaccount.google.com'),
    ...domState,
  };
};

const waitForYoutubeLoginSurface = async (timeout = 5000) => {
  return await waitForCondition(async () => {
    const state = await getYoutubeSessionState();
    if (
      state.hasAccountMenu ||
      state.hasSignInLink ||
      state.isOnGoogleAuth
    ) {
      return state;
    }

    return null;
  }, { timeout });
};

const checkLoginStatus = async () => {
  try {
    const state = await waitForYoutubeLoginSurface(1500);
    return !!(state && state.hasAccountMenu && !state.hasSignInLink);
  } catch (err) {
    return false;
  }
};

const settleLoggedInSession = async () => {
  try {
    let state = await getYoutubeSessionState();

    if (state.hasAccountMenu && !state.hasSignInLink) {
      return true;
    }

    if (state.isOnGoogleAuth || !state.isOnYoutube) {
      try {
        await page.goto('https://www.youtube.com/');
      } catch (err) {
        return false;
      }

      await waitForYoutubeLoginSurface(5000);
      state = await getYoutubeSessionState();
    }

    if (state.hasInterstitialButtons) {
      const dismissedInterstitial = await page.evaluate(`
        (() => {
          const buttons = document.querySelectorAll('button, a, tp-yt-paper-button');
          for (const btn of buttons) {
            const text = (btn.textContent || '').trim().toLowerCase();
            if (
              text === 'not now' ||
              text === 'skip' ||
              text === 'no thanks' ||
              text === 'continue' ||
              text === 'done'
            ) {
              btn.click();
              return true;
            }
          }
          return false;
        })()
      `);

      if (dismissedInterstitial) {
        await waitForYoutubeLoginSurface(2500);
        state = await getYoutubeSessionState();
      }
    }

    return !!(state.hasAccountMenu && !state.hasSignInLink);
  } catch (err) {
    return false;
  }
};

const openAvatarMenu = async () => {
  await page.evaluate(`
    (() => {
      const avatarBtn = document.querySelector('button#avatar-btn');
      if (avatarBtn) avatarBtn.click();
    })()
  `);

  await waitForCondition(async () => {
    const menuIsOpen = await page.evaluate(`
      (() => {
        return !!document.querySelector(
          'ytd-multi-page-menu-renderer, tp-yt-paper-dialog, paper-dialog'
        );
      })()
    `);

    return menuIsOpen;
  }, { timeout: 2500 });
};

// ─── Email Extraction ────────────────────────────────────────

const extractEmail = async () => {
  try {
    // Open avatar dropdown
    await openAvatarMenu();

    const scanForEmail = `
      (() => {
        const emailRegex = /[^\\s@<>"']+@[^\\s@<>"'.]+\\.[^\\s@<>"']+/;
        const containers = document.querySelectorAll(
          'ytd-multi-page-menu-renderer, tp-yt-paper-dialog, ' +
          'paper-dialog, [id*="account-name"], [id*="email"]'
        );
        for (const container of containers) {
          const leaves = container.querySelectorAll('*');
          for (const el of leaves) {
            if (el.children.length > 0) continue;
            const text = (el.textContent || '').trim();
            const match = text.match(emailRegex);
            if (match) return match[0];
          }
        }
        return null;
      })()
    `;

    let emailText = await page.evaluate(scanForEmail);

    // Fallback: click "Switch account" if visible and search there
    if (!emailText) {
      const switched = await page.evaluate(`
        (() => {
          const btns = Array.from(document.querySelectorAll('button, a, yt-button-shape, ytd-button-renderer'));
          for (const btn of btns) {
            const text = (btn.textContent || '').trim().toLowerCase();
            if (text === 'switch account') {
              btn.click();
              return true;
            }
          }
          return false;
        })()
      `);
      if (switched) {
        await waitForCondition(async () => {
          return await page.evaluate(scanForEmail);
        }, { timeout: 2000 });
        emailText = await page.evaluate(scanForEmail);
      }
    }

    // Close menu
    await page.evaluate(`(() => { document.body.click(); })()`);

    return emailText || null;
  } catch (err) {
    return null;
  }
};

// ─── Channel URL (from avatar menu) ──────────────────────────

const getChannelUrlFromMenu = async () => {
  // Open avatar menu
  await openAvatarMenu();

  const channelUrl = await page.evaluate(`
    (() => {
      // Primary: read handle directly from the active-account header element
      const handleEl = document.querySelector(
        'yt-formatted-string#channel-handle, ' +
        'ytd-active-account-header-renderer yt-formatted-string#channel-handle'
      );
      if (handleEl) {
        const handle = (handleEl.textContent || '').trim();
        if (handle.startsWith('@')) {
          return 'https://www.youtube.com/' + handle;
        }
      }

      // Fallback: look for a channel link in the dropdown, skip utility pages
      const links = document.querySelectorAll('a[href*="/@"], a[href*="/channel/"]');
      for (const link of links) {
        const href = link.getAttribute('href') || '';
        if (
          (href.includes('/@') || href.includes('/channel/')) &&
          !href.includes('/edit') &&
          !href.includes('/create') &&
          !href.includes('/monetization')
        ) {
          return href.startsWith('http')
            ? href
            : 'https://www.youtube.com' + href;
        }
      }
      return null;
    })()
  `);

  // Close menu
  await page.evaluate(`(() => { document.body.click(); })()`);

  return channelUrl;
};

// ─── Profile Extraction ───────────────────────────────────────

const extractChannelProfile = async (channelUrl) => {
  await page.goto(channelUrl);
  await page.sleep(2000);

  const baseData = await page.evaluate(`
    (() => {
      const url = window.location.href;
      const handleMatch = url.match(/\\/@([^/?#]+)/);
      const channelIdMatch = url.match(/\\/channel\\/([^/?#]+)/);

      const titleEl = document.querySelector(
        'ytd-channel-name yt-formatted-string, ' +
        '#channel-name yt-formatted-string, ' +
        'h1'
      );
      const avatarImg = document.querySelector(
        'yt-img-shadow#avatar img, #avatar img'
      );

      return {
        channelUrl: url,
        handle: handleMatch ? '@' + handleMatch[1] : null,
        channelId: channelIdMatch ? channelIdMatch[1] : null,
        channelTitle: titleEl ? titleEl.textContent.trim() : null,
        avatarUrl: avatarImg ? avatarImg.src : null
      };
    })()
  `);

  // Navigate to About tab for joined date, stats, description
  const aboutData = {
    joinedDate: null,
    description: null,
    subscriberCount: null,
    viewCount: null,
    videoCount: null,
    country: null
  };

  try {
    // Try clicking About tab
    const clicked = await page.evaluate(`
      (() => {
        const tabs = document.querySelectorAll(
          'tp-yt-paper-tab, ytd-tab-renderer, yt-tab-shape'
        );
        for (const tab of tabs) {
          const text = (tab.textContent || '').trim().toLowerCase();
          if (text === 'about') {
            tab.click();
            return true;
          }
        }
        return false;
      })()
    `);

    if (!clicked) {
      const aboutUrl = channelUrl.replace(/\/$/, '') + '/about';
      await page.goto(aboutUrl);
    }

    await page.sleep(2000);

    const aboutExtracted = await page.evaluate(`
      (() => {
        let joinedDate = null;
        let subscriberCountRaw = null;
        let viewCountRaw = null;
        let videoCountRaw = null;
        let country = null;
        let description = null;

        // Collect all visible leaf text nodes
        const texts = [];
        document.querySelectorAll('yt-formatted-string, span, td, dd').forEach(el => {
          if (el.children.length === 0) {
            const t = (el.textContent || '').trim();
            if (t.length > 0) texts.push(t);
          }
        });

        for (const t of texts) {
          if (!joinedDate && /^joined/i.test(t)) {
            joinedDate = t.replace(/^joined\\s*/i, '').trim();
          }
          if (!subscriberCountRaw && /subscriber/i.test(t)) {
            subscriberCountRaw = t;
          }
          if (!viewCountRaw && /view/i.test(t) && /\\d/.test(t)) {
            viewCountRaw = t;
          }
          if (!videoCountRaw && /video/i.test(t) && /\\d/.test(t)) {
            videoCountRaw = t;
          }
        }

        // Description
        const descEl = document.querySelector(
          '#description-container yt-formatted-string, ' +
          '#description yt-formatted-string, ' +
          'ytd-channel-about-metadata-renderer #description yt-formatted-string'
        );
        if (descEl) description = descEl.textContent.trim() || null;

        // Country: look for location field in about metadata
        const locationEl = document.querySelector(
          '#details-container ytd-channel-about-metadata-renderer span,' +
          'ytd-channel-about-metadata-renderer [id*="country"],' +
          'ytd-channel-about-metadata-renderer yt-formatted-string'
        );
        if (locationEl) {
          const t = (locationEl.textContent || '').trim();
          if (
            t.length > 0 && t.length < 60 &&
            !/\\d/.test(t) &&
            !/subscriber|view|video|join/i.test(t)
          ) {
            country = t;
          }
        }

        return { joinedDate, subscriberCountRaw, viewCountRaw, videoCountRaw, country, description };
      })()
    `);

    Object.assign(aboutData, {
      joinedDate: aboutExtracted.joinedDate,
      description: aboutExtracted.description,
      country: aboutExtracted.country,
      subscriberCount: parseCount(aboutExtracted.subscriberCountRaw),
      viewCount: parseCount(aboutExtracted.viewCountRaw),
      videoCount: parseCount(aboutExtracted.videoCountRaw)
    });
  } catch (err) {
    // Silently continue with null stats
  }

  return { ...baseData, ...aboutData };
};

// ─── Subscriptions ────────────────────────────────────────────


const scrapeSubscriptions = async () => {
  await page.goto('https://www.youtube.com/feed/channels');
  await page.sleep(2000);

  // Scroll just enough to ensure the first MAX_SUBS items are rendered
  for (let i = 0; i < 3; i++) {
    await page.evaluate(`window.scrollBy(0, window.innerHeight * 2)`);
    await page.sleep(800);
  }

  const raw = await page.evaluate(`
    (() => {
      const results = [];
      const channels = document.querySelectorAll('ytd-channel-renderer');

      for (const channel of channels) {
        if (results.length >= ${MAX_SUBS}) break;

        // Channel title
        const titleEl = channel.querySelector(
          'ytd-channel-name#channel-title yt-formatted-string#text, ' +
          'ytd-channel-name yt-formatted-string#text'
        );

        // Link element (for URL + handle/channelId)
        const linkEl = channel.querySelector(
          '#main-link, a[href*="/@"], a[href*="/channel/"]'
        );

        if (!titleEl || !linkEl) continue;

        const href = linkEl.getAttribute('href') || '';
        const channelUrl = href.startsWith('http')
          ? href
          : 'https://www.youtube.com' + href;

        const handleMatch = href.match(/\\/@([^/?#]+)/);
        const channelIdMatch = href.match(/\\/channel\\/([^/?#]+)/);

        // Handle text: #metadata yt-formatted-string#subscribers holds "@handle"
        const handleEl = channel.querySelector('#metadata yt-formatted-string#subscribers');
        const handle = handleEl
          ? (handleEl.textContent || '').trim() || null
          : (handleMatch ? '@' + handleMatch[1] : null);

        // Subscriber count: #metadata span#video-count holds "5.3m subscribers"
        const subEl = channel.querySelector('#metadata span#video-count');
        const subscriberCountText = subEl ? (subEl.textContent || '').trim() || null : null;

        // Description
        const descEl = channel.querySelector('yt-formatted-string#description');
        const description = descEl ? (descEl.textContent || '').trim() || null : null;

        // isVerified: presence of any badge-shape inside the channel name area
        const badgeEl = channel.querySelector(
          'ytd-channel-name badge-shape, ' +
          'ytd-channel-name .badge-shape, ' +
          'ytd-badge-supported-renderer badge-shape'
        );
        const isVerified = !!badgeEl;

        // isBellNotification: active bell button has aria-label containing "All"
        // or the notification button is not in the "none" state
        const bellBtn = channel.querySelector(
          'ytd-subscription-notification-toggle-button-renderer-next button, ' +
          '[aria-label*="All notifications"], ' +
          'yt-button-shape[aria-label*="notification"] button'
        );
        let isBellNotification = false;
        if (bellBtn) {
          const label = (bellBtn.getAttribute('aria-label') || '').toLowerCase();
          isBellNotification = label.includes('all') && !label.includes('none');
        }

        // Avatar
        const avatarImg = channel.querySelector('yt-img-shadow img, img#img');

        results.push({
          channelTitle: (titleEl.textContent || '').trim(),
          channelUrl,
          handle,
          channelId: channelIdMatch ? channelIdMatch[1] : null,
          avatarUrl: avatarImg ? avatarImg.src : null,
          subscriberCountText,
          description,
          isVerified,
          isBellNotification
        });
      }
      return results;
    })()
  `);

  // Attach parsed numeric subscriberCount in Node (avoids duplicating parse logic in evaluate)
  return (raw || []).map(item => ({
    ...item,
    subscriberCount: parseCount(item.subscriberCountText)
  }));
};

// ─── Playlists (from Library) ─────────────────────────────────

const scrapePlaylists = async () => {
  await page.goto('https://www.youtube.com/feed/playlists');
  await page.sleep(2000);

  // Scroll to ensure at least MAX_PLAYLISTS cards are rendered
  for (let i = 0; i < MAX_SCROLLS_PLAYLISTS; i++) {
    await page.evaluate(`window.scrollBy(0, window.innerHeight * 2)`);
    await page.sleep(1000);
  }

  // Step 1: collect up to MAX_PLAYLISTS playlist URLs from the list page
  const links = await page.evaluate(`
    (() => {
      const seen = new Set();
      const results = [];

      const tryAdd = (href) => {
        if (!href) return;
        const m = href.match(/[?&]list=([^&#]+)/);
        if (!m) return;
        const playlistId = m[1];
        if (playlistId === 'LL' || playlistId === 'WL' || seen.has(playlistId)) return;
        seen.add(playlistId);
        const url = href.startsWith('http') ? href : 'https://www.youtube.com' + href;
        results.push({ playlistId, url });
      };

      // Primary: grid / list renderers
      document.querySelectorAll(
        'ytd-playlist-renderer, ytd-grid-playlist-renderer, ytd-compact-playlist-renderer'
      ).forEach(pl => {
        const a = pl.querySelector('a[href*="list="]');
        if (a) tryAdd(a.getAttribute('href'));
      });

      // Fallback: any anchor with list= in href
      if (results.length === 0) {
        document.querySelectorAll('a[href*="playlist?list="]').forEach(a => {
          tryAdd(a.getAttribute('href'));
        });
      }

      return results;
    })()
  `);

  const playlistLinks = (links || []).slice(0, MAX_PLAYLISTS);

  // Step 2: visit each playlist page to read its header metadata
  const allPlaylists = [];
  for (const { playlistId, url } of playlistLinks) {
    try {
      await page.goto(url);
      await page.sleep(1500);

      const meta = await page.evaluate(`
        (() => {
          // Title — new page-header model
          const titleEl = document.querySelector(
            'yt-dynamic-text-view-model h1 span, ' +
            '.yt-page-header-view-model__page-header-title h1 span, ' +
            'h1#title, h1 yt-formatted-string'
          );
          const title = titleEl ? (titleEl.textContent || '').trim() || null : null;

          // Owner — avatar stack link, e.g. "by Ateet Tiwari"
          const ownerLinkEl = document.querySelector('yt-avatar-stack-view-model a');
          let owner = null;
          let ownerUrl = null;
          if (ownerLinkEl) {
            owner = (ownerLinkEl.textContent || '').trim().replace(/^by\\s+/i, '') || null;
            const h = ownerLinkEl.getAttribute('href') || '';
            ownerUrl = h ? (h.startsWith('http') ? h : 'https://www.youtube.com' + h) : null;
          }

          // Metadata text spans: "Playlist", "Public"/"Private"/"Unlisted",
          // "9 videos", "No views" / "2.3K views"
          const metaTexts = Array.from(
            document.querySelectorAll('.yt-content-metadata-view-model__metadata-text')
          ).map(el => (el.textContent || '').trim()).filter(Boolean);

          let privacy = null;
          let videoCountRaw = null;
          let viewsText = null;

          for (const t of metaTexts) {
            if (!privacy && /^(public|private|unlisted)$/i.test(t)) {
              privacy = t.charAt(0).toUpperCase() + t.slice(1).toLowerCase();
            } else if (videoCountRaw == null && /\\d/.test(t) && /video/i.test(t)) {
              videoCountRaw = t;
            } else if (viewsText == null && /view/i.test(t)) {
              viewsText = t;
            }
          }

          return { title, owner, ownerUrl, privacy, videoCountRaw, viewsText };
        })()
      `);

      allPlaylists.push({
        playlistId,
        url,
        title: meta.title,
        owner: meta.owner,
        ownerUrl: meta.ownerUrl,
        privacy: meta.privacy,
        videoCount: parseCount(meta.videoCountRaw),
        views: meta.viewsText != null
          ? (/no views/i.test(meta.viewsText) ? 0 : parseCount(meta.viewsText))
          : null
      });
    } catch (_) {
      allPlaylists.push({
        playlistId, url,
        title: null, owner: null, ownerUrl: null,
        privacy: null, videoCount: null, views: null
      });
    }
  }

  return allPlaylists;
};

// ─── Generic Playlist Page Scraper ────────────────────────────
// Used for: user playlists, Liked Videos (LL), Watch Later (WL)

const scrapePlaylistPage = async (playlistUrl, maxScrolls) => {
  await page.goto(playlistUrl);
  await page.sleep(2000);

  const seen = new Set();
  const allItems = [];
  let noChangeRounds = 0;

  for (let scroll = 0; scroll < maxScrolls; scroll++) {
    const batch = await page.evaluate(`
      (() => {
        const results = [];
        const videos = document.querySelectorAll(
          'ytd-playlist-video-renderer, ytd-playlist-panel-video-renderer'
        );
        for (const video of videos) {
          const titleEl = video.querySelector(
            '#video-title, a#video-title span, span#video-title, ' +
            'a#video-title yt-formatted-string'
          );
          const linkEl = video.querySelector(
            'a[href*="/watch"], a[href*="/shorts/"]'
          );
          const channelEl = video.querySelector(
            'ytd-channel-name a, #channel-name a, .ytd-channel-name a'
          );
          const thumbImg = video.querySelector('ytd-thumbnail img, img#img');
          const durationEl = video.querySelector(
            'ytd-thumbnail-overlay-time-status-renderer span, ' +
            'span.ytd-thumbnail-overlay-time-status-renderer'
          );

          if (!titleEl || !linkEl) continue;

          const href = linkEl.getAttribute('href') || '';
          const url = href.startsWith('http')
            ? href
            : 'https://www.youtube.com' + href;

          const videoIdMatch =
            url.match(/[?&]v=([^&#]+)/) || url.match(/\\/shorts\\/([^?&#]+)/);
          const videoId = videoIdMatch ? videoIdMatch[1] : null;

          const channelHref = channelEl ? channelEl.getAttribute('href') || '' : '';
          const channelUrl = channelHref
            ? channelHref.startsWith('http')
              ? channelHref
              : 'https://www.youtube.com' + channelHref
            : null;

          results.push({
            videoId,
            videoUrl: url,
            videoTitle: (titleEl.textContent || '').trim(),
            channelTitle: channelEl ? (channelEl.textContent || '').trim() : null,
            channelUrl,
            durationText: durationEl ? (durationEl.textContent || '').trim() : null,
            thumbnailUrl: thumbImg ? thumbImg.src : null
          });
        }
        return results;
      })()
    `);

    let newItemsCount = 0;
    for (const item of (batch || [])) {
      const key = item.videoId || item.videoUrl;
      if (key && !seen.has(key)) {
        seen.add(key);
        allItems.push(item);
        newItemsCount++;
      }
    }

    if (newItemsCount === 0) {
      noChangeRounds++;
      if (noChangeRounds >= 2) break;
    } else {
      noChangeRounds = 0;
    }

    await page.evaluate(`window.scrollBy(0, window.innerHeight * 2)`);
    await page.sleep(1500);
  }

  return allItems;
};

// ─── Watch History Scraper ────────────────────────────────────

const scrapeHistory = async () => {
  await page.goto('https://www.youtube.com/feed/history');
  await page.sleep(2000);

  // Scroll a few times to render enough items
  for (let i = 0; i < MAX_SCROLLS_HISTORY; i++) {
    await page.evaluate(`window.scrollBy(0, window.innerHeight * 2)`);
    await page.sleep(800);
  }

  const items = await page.evaluate(`
    (() => {
      const results = [];
      const seen = new Set();

      const sections = document.querySelectorAll('ytd-item-section-renderer');

      for (const section of sections) {
        if (results.length >= ${MAX_HISTORY_ITEMS}) break;

        // Section date header: "Today", "Yesterday", "Jan 23, 2026", etc.
        // New DOM: ytd-item-section-header-renderer > #header > #title (a plain div)
        const headerTitleEl = section.querySelector(
          'ytd-item-section-header-renderer #header #title, ' +
          '#header #title'
        );
        const watchedAtText = headerTitleEl
          ? (headerTitleEl.textContent || '').trim() || null
          : null;

        // History page now uses yt-lockup-view-model (new renderer)
        // Each lockup has class "content-id-{videoId}" for easy extraction
        const lockups = section.querySelectorAll('yt-lockup-view-model');

        for (const lockup of lockups) {
          if (results.length >= ${MAX_HISTORY_ITEMS}) break;

          // videoId from the content-id-* class
          const contentIdClass = Array.from(lockup.classList)
            .find(c => c.startsWith('content-id-'));
          const videoId = contentIdClass
            ? contentIdClass.replace('content-id-', '')
            : null;

          // Video URL — thumbnail anchor or title anchor
          const linkEl = lockup.querySelector(
            'a.yt-lockup-view-model__content-image, ' +
            'a.yt-lockup-metadata-view-model__title'
          );
          if (!linkEl) continue;

          const href = linkEl.getAttribute('href') || '';
          const videoUrl = href.startsWith('http')
            ? href
            : 'https://www.youtube.com' + href;

          // De-dup across scroll re-evaluations
          const key = videoId || videoUrl;
          if (seen.has(key)) continue;
          seen.add(key);

          // Title: prefer h3[title] attribute (full, untruncated)
          const titleEl = lockup.querySelector(
            'h3.yt-lockup-metadata-view-model__heading-reset'
          );
          const videoTitle = titleEl
            ? (titleEl.getAttribute('title') || titleEl.textContent || '').trim() || null
            : null;

          // Channel name: from avatar aria-label ("Go to channel X")
          const avatarEl = lockup.querySelector('[aria-label^="Go to channel"]');
          const channelTitle = avatarEl
            ? (avatarEl.getAttribute('aria-label') || '')
                .replace(/^Go to channel\\s+/i, '').trim() || null
            : null;

          // Views: last .metadata-text span inside the first padded row
          const firstRow = lockup.querySelector(
            '.yt-content-metadata-view-model__metadata-row--metadata-row-padding'
          );
          let views = null;
          if (firstRow) {
            const metaSpans = firstRow.querySelectorAll(
              '.yt-content-metadata-view-model__metadata-text'
            );
            const lastSpan = metaSpans[metaSpans.length - 1];
            if (lastSpan) views = (lastSpan.textContent || '').trim() || null;
          }

          // Description: multi-line text snippet
          const descEl = lockup.querySelector(
            '.yt-content-metadata-view-model__metadata-text-max-lines-2'
          );
          const description = descEl
            ? (descEl.textContent || '').trim() || null
            : null;

          if (!videoTitle && !videoId) continue;

          results.push({
            watchedAtText,
            videoId,
            videoUrl,
            videoTitle,
            channelTitle,
            views,
            description
          });
        }
      }

      return results;
    })()
  `);

  return (items || []).slice(0, MAX_HISTORY_ITEMS);
};

// ─── Main Connector Flow ──────────────────────────────────────

(async () => {
  try {
    const TOTAL_PHASES = 8;

    // ═══ Login Phase ═══
    await page.setData('status', 'Checking login status...');
    await page.goto('https://www.youtube.com/');
    await waitForYoutubeLoginSurface(5000);

    state.isLoggedIn = await checkLoginStatus();

    if (!state.isLoggedIn) {
      // Navigate to Google sign-in for YouTube
      await page.goto('https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F');
      await waitForCondition(async () => {
        const currentUrl = await page.url();
        if (currentUrl.includes('challenge') || currentUrl.includes('youtube.com')) {
          return true;
        }

        return await page.evaluate(`
          !!document.querySelector('input[type="email"]') ||
          !!document.querySelector('#identifierId') ||
          !!document.querySelector('input[type="password"]') ||
          !!document.querySelector('input[name="Passwd"]') ||
          !!document.querySelector('input[name="totpPin"]') ||
          !!document.querySelector('input[type="tel"]')
        `);
      }, { timeout: 5000 });

      // Check if Google login email field is present
      const hasEmailField = await page.evaluate(`
        !!document.querySelector('input[type="email"]') ||
        !!document.querySelector('#identifierId')
      `);

      const supportsRequestInput = typeof page.requestInput === 'function';

      if (supportsRequestInput && hasEmailField) {
        const { email } = await page.requestInput({
          message: "Log in to YouTube with your Google account — enter your email",
          schema: {
            type: "object",
            properties: {
              email: { type: "string", description: "Google account email" },
            },
            required: ["email"],
          },
        });

        await page.evaluate(`
          (() => {
            const emailInput = document.querySelector('input[type="email"]') ||
                               document.querySelector('#identifierId');
            if (emailInput) {
              emailInput.value = ${JSON.stringify(email)};
              emailInput.dispatchEvent(new Event('input', {bubbles:true}));
              emailInput.dispatchEvent(new Event('change', {bubbles:true}));
            }
          })()
        `);
        await waitForCondition(async () => {
          return !!(await page.evaluate(`
            (() => {
              const nextButton =
                document.querySelector('#identifierNext button') ||
                document.querySelector('button[type="submit"]') ||
                document.querySelector('#identifierNext');
              return nextButton && !nextButton.disabled;
            })()
          `));
        }, { timeout: 2000 });
        // Click Next button
        await page.evaluate(`
          (() => {
            const btn = document.querySelector('#identifierNext button') ||
                        document.querySelector('button[type="submit"]') ||
                        document.querySelector('#identifierNext');
            if (btn) btn.click();
          })()
        `);
        await waitForCondition(async () => {
          const currentUrl = await page.url();
          if (currentUrl.includes('challenge') || currentUrl.includes('youtube.com')) {
            return true;
          }

          return await page.evaluate(`
            !!document.querySelector('input[type="password"]') ||
            !!document.querySelector('input[name="Passwd"]') ||
            !!document.querySelector('input[name="totpPin"]') ||
            !!document.querySelector('input[type="tel"]')
          `);
        }, { timeout: 8000 });

        // Password page
        const hasPasswordField = await page.evaluate(`
          !!document.querySelector('input[type="password"]') ||
          !!document.querySelector('input[name="Passwd"]')
        `);

        if (hasPasswordField) {
          const { password } = await page.requestInput({
            message: "Enter your Google account password",
            schema: {
              type: "object",
              properties: {
                password: { type: "string", format: "password" },
              },
              required: ["password"],
            },
          });

          await page.evaluate(`
            (() => {
              const passwordInput = document.querySelector('input[type="password"]') ||
                                    document.querySelector('input[name="Passwd"]');
              if (passwordInput) {
                passwordInput.value = ${JSON.stringify(password)};
                passwordInput.dispatchEvent(new Event('input', {bubbles:true}));
                passwordInput.dispatchEvent(new Event('change', {bubbles:true}));
              }
            })()
          `);
          await waitForCondition(async () => {
            return !!(await page.evaluate(`
              (() => {
                const nextButton =
                  document.querySelector('#passwordNext button') ||
                  document.querySelector('button[type="submit"]') ||
                  document.querySelector('#passwordNext');
                return nextButton && !nextButton.disabled;
              })()
            `));
          }, { timeout: 2000 });
          await page.evaluate(`
            (() => {
              const btn = document.querySelector('#passwordNext button') ||
                          document.querySelector('button[type="submit"]') ||
                          document.querySelector('#passwordNext');
              if (btn) btn.click();
            })()
          `);
          await waitForCondition(async () => {
            const currentUrl = await page.url();
            if (currentUrl.includes('challenge') || currentUrl.includes('youtube.com')) {
              return true;
            }

            return await page.evaluate(`
              !!document.querySelector('input[name="totpPin"]') ||
              !!document.querySelector('input[type="tel"]')
            `);
          }, { timeout: 10000 });
        }

        // Handle 2FA if present
        const needs2fa = await page.evaluate(`
          !!document.querySelector('input[name="totpPin"]') ||
          !!document.querySelector('input[type="tel"]') ||
          window.location.href.includes('challenge')
        `);
        if (needs2fa) {
          const { code } = await page.requestInput({
            message: "Enter your Google 2FA verification code",
            schema: {
              type: "object",
              properties: { code: { type: "string", description: "2FA code from authenticator app or SMS" } },
              required: ["code"],
            },
          });
          await page.evaluate(`
            (() => {
              const input = document.querySelector('input[name="totpPin"]') ||
                            document.querySelector('input[type="tel"]') ||
                            document.querySelector('#totpPin');
              if (input) {
                input.value = ${JSON.stringify(code)};
                input.dispatchEvent(new Event('input', {bubbles:true}));
                input.dispatchEvent(new Event('change', {bubbles:true}));
              }
            })()
          `);
          await waitForCondition(async () => {
            return !!(await page.evaluate(`
              (() => {
                const nextButton =
                  document.querySelector('#totpNext button') ||
                  document.querySelector('button[type="submit"]');
                return nextButton && !nextButton.disabled;
              })()
            `));
          }, { timeout: 2000 });
          await page.evaluate(`
            (() => {
              const btn = document.querySelector('#totpNext button') ||
                          document.querySelector('button[type="submit"]');
              if (btn) btn.click();
            })()
          `);
          await waitForCondition(async () => {
            const currentUrl = await page.url();
            return currentUrl.includes('youtube.com') || currentUrl.includes('challenge');
          }, { timeout: 10000 });
        }

        // Dismiss Google interstitials that appear after login
        // (consent screens, "I agree", recovery prompts, etc.)
        for (let dismissAttempt = 0; dismissAttempt < 5; dismissAttempt++) {
          const dismissed = await page.evaluate(`
            (() => {
              const buttons = document.querySelectorAll('button, input[type="button"], input[type="submit"]');
              for (const btn of buttons) {
                const text = (btn.textContent || btn.value || '').trim().toLowerCase();
                // Google consent / Terms of Service
                if (text === 'i agree' || text === 'accept' || text === 'accept all' ||
                    text === 'agree' || text === 'continue') {
                  btn.click();
                  return 'dismissed: ' + text;
                }
                // "Not now" for recovery phone/email prompts, 2-step verification setup
                if (text === 'not now' || text === 'skip' || text === 'no thanks' ||
                    text === 'done' || text === 'next') {
                  // Only click "next" if it looks like a consent/interstitial, not a login step
                  if (text === 'next' && document.querySelector('input[type="password"]')) continue;
                  btn.click();
                  return 'dismissed: ' + text;
                }
                // "Confirm" for "Is this your device?" prompts
                if (text === 'confirm' || text === 'yes') {
                  btn.click();
                  return 'dismissed: ' + text;
                }
              }

              // Cookie consent — Google-style
              const consentBtns = document.querySelectorAll('[aria-label*="Accept all"], [aria-label*="Reject all"]');
              if (consentBtns.length > 0) {
                consentBtns[0].click();
                return 'dismissed cookie consent';
              }

              return null;
            })()
          `);
          if (!dismissed) break;
          await waitForYoutubeLoginSurface(3000);
        }

        // Wait for redirect to YouTube
        for (let i = 0; i < 10; i++) {
          state.isLoggedIn = await settleLoggedInSession();
          if (state.isLoggedIn) break;
          await waitForYoutubeLoginSurface(2000);
        }
      }

      // Fallback to headed browser if programmatic login failed
      if (!state.isLoggedIn) {
        const { headed } = await page.showBrowser('https://www.youtube.com/');
        if (headed) {
          await page.setData('status', 'Please complete login in the browser...');
          await page.promptUser(
            'Complete any remaining verification, then click "Done".',
            async () => checkLoginStatus(),
            2000
          );
          await page.goHeadless({ resumeUrl: 'https://www.youtube.com/' });
        }
        state.isLoggedIn = await settleLoggedInSession();
      }

      await page.setData('status', 'Login completed');
    } else {
      await page.setData('status', 'Session restored from previous login');
    }

    if (!state.isLoggedIn) {
      await page.setData('error', 'Login failed or timed out');
      return { error: 'Login failed or timed out' };
    }

    // ═══ Phase 1: Extract Email ═══
    await page.setProgress({
      phase: { step: 1, total: TOTAL_PHASES, label: 'Extracting account info' },
      message: 'Fetching account email...',
    });

    state.email = await extractEmail();
    await page.setData('status', `Logged in as ${state.email || 'unknown'}`);

    await page.setProgress({
      phase: { step: 1, total: TOTAL_PHASES, label: 'Extracting account info' },
      message: state.email ? `Email: ${state.email}` : 'Email not found',
    });

    // ═══ Phase 2: Profile ═══
    await page.setProgress({
      phase: { step: 2, total: TOTAL_PHASES, label: 'Fetching channel profile' },
      message: 'Navigating to your channel...',
    });

    try {
      const channelUrl = await getChannelUrlFromMenu();

      if (channelUrl) {
        const channelData = await extractChannelProfile(channelUrl);
        state.profile = {
          email: state.email,
          channelUrl: channelData.channelUrl,
          handle: channelData.handle,
          channelTitle: channelData.channelTitle,
          channelId: channelData.channelId,
          avatarUrl: channelData.avatarUrl,
          joinedDate: channelData.joinedDate,
          description: channelData.description,
          subscriberCount: channelData.subscriberCount,
          viewCount: channelData.viewCount,
          videoCount: channelData.videoCount,
          country: channelData.country
        };
      } else {
        state.profile = { email: state.email };
      }
    } catch (err) {
      state.profile = { email: state.email };
    }

    await page.setData('profile', state.profile);
    await page.setProgress({
      phase: { step: 2, total: TOTAL_PHASES, label: 'Fetching channel profile' },
      message: `Profile: ${state.profile.handle || state.profile.channelTitle || 'collected'}`,
    });

    // ═══ Phase 3: Subscriptions ═══
    await page.setProgress({
      phase: { step: 3, total: TOTAL_PHASES, label: 'Fetching subscriptions' },
      message: 'Loading subscriptions...',
    });

    try {
      state.subscriptions = await scrapeSubscriptions();
    } catch (err) {
      state.subscriptions = [];
    }

    await page.setData('subscriptions', { count: state.subscriptions.length });
    await page.setProgress({
      phase: { step: 3, total: TOTAL_PHASES, label: 'Fetching subscriptions' },
      message: `Found ${state.subscriptions.length} subscriptions`,
      count: state.subscriptions.length,
    });

    // ═══ Phase 4: Playlists ═══
    await page.setProgress({
      phase: { step: 4, total: TOTAL_PHASES, label: 'Fetching playlists' },
      message: 'Loading playlists from library...',
    });

    try {
      state.playlists = await scrapePlaylists();
    } catch (err) {
      state.playlists = [];
    }

    await page.setData('playlists', { count: state.playlists.length });
    await page.setProgress({
      phase: { step: 4, total: TOTAL_PHASES, label: 'Fetching playlists' },
      message: `Found ${state.playlists.length} playlists`,
      count: state.playlists.length,
    });

    // ═══ Phase 5: Playlist Items ═══
    await page.setProgress({
      phase: { step: 5, total: TOTAL_PHASES, label: 'Fetching playlist items' },
      message: 'Collecting videos from playlists...',
    });

    const playlistsToProcess = state.playlists.slice(0, MAX_PLAYLISTS);
    for (let i = 0; i < playlistsToProcess.length; i++) {
      const playlist = playlistsToProcess[i];
      if (!playlist.url || !playlist.playlistId) continue;

      await page.setProgress({
        phase: { step: 5, total: TOTAL_PHASES, label: 'Fetching playlist items' },
        message: `Playlist ${i + 1}/${playlistsToProcess.length}: "${playlist.title}"`,
        count: i + 1,
      });

      try {
        const items = await scrapePlaylistPage(playlist.url, MAX_SCROLLS_PLAYLIST_ITEMS);
        state.playlistItems[playlist.playlistId] = {
          playlistId: playlist.playlistId,
          playlistTitle: playlist.title,
          playlistUrl: playlist.url,
          items
        };
      } catch (err) {
        // Skip this playlist on error
      }
    }

    // ═══ Phase 6: Liked Videos (playlist LL) ═══
    await page.setProgress({
      phase: { step: 6, total: TOTAL_PHASES, label: 'Fetching liked videos' },
      message: 'Loading liked videos...',
    });

    try {
      state.likes = await scrapePlaylistPage(
        'https://www.youtube.com/playlist?list=LL',
        MAX_SCROLLS_PLAYLIST_ITEMS
      );
    } catch (err) {
      state.likes = [];
      await page.setData('warning', 'Could not access liked videos (may be private)');
    }

    await page.setData('likes', { count: state.likes.length });
    await page.setProgress({
      phase: { step: 6, total: TOTAL_PHASES, label: 'Fetching liked videos' },
      message: `Found ${state.likes.length} liked videos`,
      count: state.likes.length,
    });

    // ═══ Phase 7: Watch Later (playlist WL) ═══
    await page.setProgress({
      phase: { step: 7, total: TOTAL_PHASES, label: 'Fetching watch later' },
      message: 'Loading watch later list...',
    });

    try {
      state.watchLater = await scrapePlaylistPage(
        'https://www.youtube.com/playlist?list=WL',
        MAX_SCROLLS_PLAYLIST_ITEMS
      );
    } catch (err) {
      state.watchLater = [];
      await page.setData('warning', 'Could not access watch later (may be empty or private)');
    }

    await page.setData('watchLater', { count: state.watchLater.length });
    await page.setProgress({
      phase: { step: 7, total: TOTAL_PHASES, label: 'Fetching watch later' },
      message: `Found ${state.watchLater.length} watch later items`,
      count: state.watchLater.length,
    });

    // ═══ Phase 8: Watch History (top 50) ═══
    await page.setProgress({
      phase: { step: 8, total: TOTAL_PHASES, label: 'Fetching watch history' },
      message: `Loading top ${MAX_HISTORY_ITEMS} history items...`,
    });

    try {
      state.history = await scrapeHistory();
    } catch (err) {
      state.history = [];
      await page.setData('warning', 'Could not access watch history');
    }

    await page.setData('history', { count: state.history.length });
    await page.setProgress({
      phase: { step: 8, total: TOTAL_PHASES, label: 'Fetching watch history' },
      message: `Found ${state.history.length} history items`,
      count: state.history.length,
    });

    // ═══ Transform to Final Schema Output ═══
    const transformDataForSchema = () => {
      const playlistsOutput = Object.values(state.playlistItems);
      const totalPlaylistItems = playlistsOutput.reduce(
        (acc, p) => acc + (p.items?.length || 0), 0
      );

      return {
        'youtube.profile': state.profile || {},
        'youtube.subscriptions': {
          subscriptions: state.subscriptions
        },
        'youtube.playlists': {
          playlists: state.playlists
        },
        'youtube.playlistItems': {
          playlists: playlistsOutput
        },
        'youtube.likes': {
          likedVideos: state.likes
        },
        'youtube.watchLater': {
          watchLater: state.watchLater
        },
        'youtube.history': {
          timeWindow: `top ${MAX_HISTORY_ITEMS} most recent items`,
          history: state.history
        },
        exportSummary: (() => {
          const totalItems =
            state.subscriptions.length +
            state.playlists.length +
            totalPlaylistItems +
            state.likes.length +
            state.watchLater.length +
            state.history.length;
          return {
            count: totalItems,
            label: totalItems === 1 ? 'item' : 'items',
            details: [
              state.subscriptions.length + ' subscriptions',
              state.playlists.length + ' playlists',
              totalPlaylistItems + ' playlist items',
              state.likes.length + ' liked videos',
              state.watchLater.length + ' watch later',
              state.history.length + ' history items'
            ].join(', ')
          };
        })(),
        timestamp: new Date().toISOString(),
        version: '1.0.0-playwright',
        platform: 'youtube'
      };
    };

    state.isComplete = true;
    const result = transformDataForSchema();

    await page.setData('result', result);
    await page.setData(
      'status',
      `Complete! ${state.subscriptions.length} subscriptions, ` +
      `${state.playlists.length} playlists, ` +
      `${state.likes.length} likes, ` +
      `${state.watchLater.length} watch later, ` +
      `${state.history.length} history items`
    );

    return { success: true, data: result };

  } catch (error) {
    await page.setData('error', error.message);
    return { success: false, error: error.message };
  }
})();
